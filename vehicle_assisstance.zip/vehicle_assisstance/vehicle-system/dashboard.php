<?php
session_start();
if(!isset($_SESSION['user_id'])) header("Location: login.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins',sans-serif;
        }

        body{
            height:100vh;
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),
                        url('https://images.unsplash.com/photo-1493238792000-8113da705763') 
                        no-repeat center center/cover;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .dashboard-card{
            width:85%;
            max-width:900px;
            padding:50px;
            border-radius:20px;
            background: rgba(255,255,255,0.08);
            border:1px solid rgba(255,255,255,0.2);
            box-shadow: 0 25px 60px rgba(0,0,0,0.6);
            text-align:center;
            color:white;
        }

        h2{
            margin-bottom:40px;
            font-weight:600;
        }

        .button-container{
            display:flex;
            justify-content:center;
            gap:30px;
            flex-wrap:wrap;
        }

        .btn{
            padding:15px 35px;
            border-radius:12px;
            text-decoration:none;
            color:white;
            font-size:16px;
            font-weight:500;
            transition:0.3s ease;
            background: linear-gradient(135deg,#1e1e2f,#3a3a5f);
            box-shadow:0 8px 20px rgba(0,0,0,0.4);
        }

        .btn:hover{
            transform:translateY(-8px);
            background: linear-gradient(135deg,#ff9800,#ff5722);
            box-shadow:0 15px 30px rgba(0,0,0,0.7);
        }

        .logout-btn{
            margin-top:40px;
            background: linear-gradient(135deg,crimson,darkred);
        }

        .logout-btn:hover{
            background: linear-gradient(135deg,#ff4b5c,#b30000);
        }

        @media(max-width:768px){
            .dashboard-card{
                padding:30px;
            }
            .btn{
                width:100%;
                display:block;
            }
        }

    </style>
</head>
<body>

<div class="dashboard-card">
    <h2>Welcome, <?php echo $_SESSION['name']; ?> 👋</h2>

    <div class="button-container">
        <a href="user/add_vehicle.php" class="btn">Add Vehicle</a>
        <a href="user/request_service.php" class="btn">Request Service</a>
        <a href="user/view_requests.php" class="btn">My Requests</a>
    </div>

    <a href="logout.php" class="btn logout-btn">Logout</a>
</div>

</body>
</html>