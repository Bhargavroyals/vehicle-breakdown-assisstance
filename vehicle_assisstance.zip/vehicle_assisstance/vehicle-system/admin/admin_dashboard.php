<?php
session_start();
include "../db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit();
}

$total_users = $conn->query("SELECT COUNT(*) AS count FROM users WHERE role='user'")
                     ->fetch_assoc()['count'];

$total_mechanics = $conn->query("SELECT COUNT(*) AS count FROM users WHERE role='mechanic'")
                         ->fetch_assoc()['count'];

$total_requests = $conn->query("SELECT COUNT(*) AS count FROM service_requests")
                       ->fetch_assoc()['count'];
?>
<link rel="stylesheet" href="../css/style.css">

<h2 style="text-align:center;">Admin Dashboard</h2>

<div style="width:400px; margin:20px auto;">
    <div class="card">Total Users: <?php echo $total_users; ?></div>
    <div class="card">Total Mechanics: <?php echo $total_mechanics; ?></div>
    <div class="card">Total Service Requests: <?php echo $total_requests; ?></div>
</div>

<div style="text-align:center;">
    <a href="../logout.php">Logout</a>
</div>