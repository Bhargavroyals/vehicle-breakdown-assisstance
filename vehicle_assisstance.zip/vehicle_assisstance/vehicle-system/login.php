<?php
session_start();
include "db.php";

$error = "";

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user && password_verify($password,$user['password'])){
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        if($user['role']=="admin")
            header("Location: admin/admin_dashboard.php");
        elseif($user['role']=="mechanic")
            header("Location: mechanic/mechanic_dashboard.php");
        else
            header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid Email or Password!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins', sans-serif;
        }

        body{
            height:100vh;
            background:url('https://images.unsplash.com/photo-1493238792000-8113da705763') no-repeat center center/cover;
            display:flex;
            justify-content:center;
            align-items:center;
            position:relative;
        }

        body::before{
            content:"";
            position:absolute;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.6);
            top:0;
            left:0;
        }

        .login-card{
            position:relative;
            z-index:1;
            width:350px;
            padding:40px;
            border-radius:20px;
            backdrop-filter:blur(15px);
            background:rgba(255,255,255,0.1);
            box-shadow:0 20px 50px rgba(0,0,0,0.5);
            color:white;
            text-align:center;
        }

        .login-card h2{
            margin-bottom:30px;
            font-weight:600;
        }

        .input-group{
            margin-bottom:20px;
        }

        .input-group input{
            width:100%;
            padding:12px;
            border:none;
            border-radius:8px;
            outline:none;
            font-size:14px;
            transition:0.3s;
        }

        .input-group input:focus{
            box-shadow:0 0 10px #ff9800;
        }

        .btn{
            width:100%;
            padding:12px;
            border:none;
            border-radius:8px;
            font-size:15px;
            font-weight:500;
            cursor:pointer;
            background:linear-gradient(135deg,#1e1e2f,#3a3a5f);
            color:white;
            transition:0.3s ease;
            box-shadow:0 8px 20px rgba(0,0,0,0.3);
        }

        .btn:hover{
            transform:translateY(-5px);
            background:linear-gradient(135deg,#ff9800,#ff5722);
            box-shadow:0 15px 30px rgba(0,0,0,0.6);
        }

        .error{
            color:#ff4b5c;
            margin-bottom:15px;
            font-size:14px;
        }

        .register-link{
            margin-top:15px;
            font-size:13px;
        }

        .register-link a{
            color:#ff9800;
            text-decoration:none;
        }

        .register-link a:hover{
            text-decoration:underline;
        }

    </style>
</head>
<body>

<div class="login-card">
    <h2>Login</h2>

    <?php if($error != "") echo "<div class='error'>$error</div>"; ?>

    <form method="POST">
        <div class="input-group">
            <input type="email" name="email" placeholder="Email" required>
        </div>

        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
        </div>

        <button type="submit" name="login" class="btn">Login</button>
    </form>

    <div class="register-link">
        Don't have an account? <a href="register.php">Register</a>
    </div>
</div>

</body>
</html>