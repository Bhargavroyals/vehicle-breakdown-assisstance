<?php
session_start();

if(isset($_SESSION['role'])){
    if($_SESSION['role'] == "admin"){
        header("Location: admin/admin_dashboard.php");
        exit();
    }
    elseif($_SESSION['role'] == "mechanic"){
        header("Location: mechanic/mechanic_dashboard.php");
        exit();
    }
    else{
        header("Location: dashboard.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Assistance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body{
            margin:0;
            font-family:Arial;
            height:100vh;
            background:linear-gradient(135deg,#1e1e2f,#3a3a5f);
            display:flex;
            justify-content:center;
            align-items:center;
            color:white;
            text-align:center;
        }
        .box{
            background:rgba(255,255,255,0.1);
            padding:40px;
            border-radius:15px;
        }
        a{
            display:inline-block;
            margin:15px;
            padding:12px 25px;
            background:#ff9800;
            color:white;
            text-decoration:none;
            border-radius:8px;
        }
        a:hover{
            background:#ff5722;
        }
    </style>
</head>
<body>

<div class="box">
    <h1>Smart Vehicle Breakdown Assistance</h1>
    <p>Get instant roadside help</p>

    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
</div>

</body>
</html>