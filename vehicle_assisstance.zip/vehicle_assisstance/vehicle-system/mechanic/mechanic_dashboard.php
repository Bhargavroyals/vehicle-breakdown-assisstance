<?php
session_start();
include "../db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'mechanic'){
    header("Location: ../login.php");
    exit();
}

if(isset($_GET['accept'])){
    $id = $_GET['accept'];
    $stmt = $conn->prepare("UPDATE service_requests SET status='Accepted' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

if(isset($_GET['complete'])){
    $id = $_GET['complete'];
    $stmt = $conn->prepare("UPDATE service_requests SET status='Completed' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

$result = $conn->query("SELECT * FROM service_requests ORDER BY created_at DESC");
?>
<link rel="stylesheet" href="../css/style.css">

<h2 style="text-align:center;">Mechanic Dashboard</h2>

<div style="width:600px; margin:20px auto;">
<?php while($row = $result->fetch_assoc()){ ?>
    <div class="card">
        <p><strong>Location:</strong> <?php echo $row['location']; ?></p>
        <p><strong>Issue:</strong> <?php echo $row['issue']; ?></p>
        <p><strong>Status:</strong> <?php echo $row['status']; ?></p>

        <?php if($row['status'] == "Pending"){ ?>
            <a href="?accept=<?php echo $row['id']; ?>">Accept</a>
        <?php } ?>

        <?php if($row['status'] == "Accepted"){ ?>
            | <a href="?complete=<?php echo $row['id']; ?>">Mark Completed</a>
        <?php } ?>
    </div>
<?php } ?>
</div>

<div style="text-align:center;">
    <a href="../logout.php">Logout</a>
</div>