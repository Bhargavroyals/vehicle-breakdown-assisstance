<?php
include "db.php";

$error = "";

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
    $check->bind_param("s",$email);
    $check->execute();
    $check->store_result();

    if($check->num_rows > 0){
        $error = "Email already registered!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name,email,password,phone) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss",$name,$email,$password,$phone);
        $stmt->execute();
        header("Location: login.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins', sans-serif;
        }

        body{
            height:100vh;
            background:url('https://images.unsplash.com/photo-1493238792000-8113da705763') no-repeat center center/cover;
            display:flex;
            justify-content:center;
            align-items:center;
            position:relative;
        }

        body::before{
            content:"";
            position:absolute;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.6);
            top:0;
            left:0;
        }

        .register-card{
            position:relative;
            z-index:1;
            width:380px;
            padding:40px;
            border-radius:20px;
            backdrop-filter:blur(15px);
            background:rgba(255,255,255,0.1);
            box-shadow:0 20px 50px rgba(0,0,0,0.5);
            color:white;
            text-align:center;
        }

        .register-card h2{
            margin-bottom:25px;
            font-weight:600;
        }

        .input-group{
            margin-bottom:18px;
        }

        .input-group input{
            width:100%;
            padding:12px;
            border:none;
            border-radius:8px;
            outline:none;
            font-size:14px;
            transition:0.3s;
        }

        .input-group input:focus{
            box-shadow:0 0 10px #ff9800;
        }

        .btn{
            width:100%;
            padding:12px;
            border:none;
            border-radius:8px;
            font-size:15px;
            font-weight:500;
            cursor:pointer;
            background:linear-gradient(135deg,#1e1e2f,#3a3a5f);
            color:white;
            transition:0.3s ease;
            box-shadow:0 8px 20px rgba(0,0,0,0.3);
        }

        .btn:hover{
            transform:translateY(-5px);
            background:linear-gradient(135deg,#ff9800,#ff5722);
            box-shadow:0 15px 30px rgba(0,0,0,0.6);
        }

        .error{
            color:#ff4b5c;
            margin-bottom:15px;
            font-size:14px;
        }

        .login-link{
            margin-top:15px;
            font-size:13px;
        }

        .login-link a{
            color:#ff9800;
            text-decoration:none;
        }

        .login-link a:hover{
            text-decoration:underline;
        }

        @media(max-width:480px){
            .register-card{
                width:90%;
            }
        }

    </style>
</head>
<body>

<div class="register-card">
    <h2>Create Account</h2>

    <?php if($error != "") echo "<div class='error'>$error</div>"; ?>

    <form method="POST">
        <div class="input-group">
            <input type="text" name="name" placeholder="Full Name" required>
        </div>

        <div class="input-group">
            <input type="email" name="email" placeholder="Email Address" required>
        </div>

        <div class="input-group">
            <input type="text" name="phone" placeholder="Phone Number">
        </div>

        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
        </div>

        <button type="submit" name="register" class="btn">Register</button>
    </form>

    <div class="login-link">
        Already have an account? <a href="login.php">Login</a>
    </div>
</div>

</body>
</html>