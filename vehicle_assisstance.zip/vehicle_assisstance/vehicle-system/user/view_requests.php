<?php
session_start();
include "../db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM service_requests WHERE user_id=? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<link rel="stylesheet" href="../css/style.css">

<h2 style="text-align:center;">My Service Requests</h2>

<div style="width:600px; margin:20px auto;">
<?php while($row = $result->fetch_assoc()){ ?>
    <div class="card">
        <p><strong>Location:</strong> <?php echo $row['location']; ?></p>
        <p><strong>Issue:</strong> <?php echo $row['issue']; ?></p>
        <p><strong>Status:</strong>
            <span class="<?php echo strtolower($row['status']); ?>">
                <?php echo $row['status']; ?>
            </span>
        </p>
        <p><small><?php echo $row['created_at']; ?></small></p>
    </div>
<?php } ?>
</div>

<div style="text-align:center;">
    <a href="../dashboard.php">Back to Dashboard</a>
</div>