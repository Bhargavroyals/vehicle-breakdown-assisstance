<?php
session_start();
include "../db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

if(isset($_POST['request'])){
    $location = $_POST['location'];
    $issue    = $_POST['issue'];
    $user_id  = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO service_requests (user_id, location, issue) VALUES (?,?,?)");
    $stmt->bind_param("iss", $user_id, $location, $issue);
    $stmt->execute();

    $success = "Service requested successfully!";
}
?>
<link rel="stylesheet" href="../css/style.css">

<div class="container">
    <h2>Request Service</h2>

    <?php if(isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

    <form method="POST">
        <input type="text" name="location" placeholder="Current Location" required>
        <textarea name="issue" placeholder="Describe the issue..." required></textarea>
        <button name="request">Submit Request</button>
    </form>

    <br>
    <a href="../dashboard.php">Back to Dashboard</a>
</div>