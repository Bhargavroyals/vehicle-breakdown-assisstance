<?php
session_start();
include "../db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

if(isset($_POST['add'])){
    $vehicle_number = $_POST['vehicle_number'];
    $vehicle_type   = $_POST['vehicle_type'];
    $user_id        = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO vehicles (user_id, vehicle_number, vehicle_type) VALUES (?,?,?)");
    $stmt->bind_param("iss", $user_id, $vehicle_number, $vehicle_type);
    $stmt->execute();

    $success = "Vehicle added successfully!";
}
?>
<link rel="stylesheet" href="../css/style.css">

<div class="container">
    <h2>Add Vehicle</h2>

    <?php if(isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

    <form method="POST">
        <input type="text" name="vehicle_number" placeholder="Vehicle Number" required>
        <input type="text" name="vehicle_type" placeholder="Vehicle Type (Car/Bike/etc)" required>
        <button name="add">Add Vehicle</button>
    </form>

    <br>
    <a href="../dashboard.php">Back to Dashboard</a>
</div>